import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  name: string;
  childName: String;
  constructor() { }

  ngOnInit() {
  }
  setValue(data): void {
    this.name = data.name;
  }
  getChildName(msg: string) {
    this.childName = msg;
  }

}
