package com.cg.capStore.service;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.capStore.bean.Cart;
import com.cg.capStore.bean.Products;
import com.cg.capStore.dao.CartDao;
import com.cg.capStore.dao.ProductsDao;
import com.cg.capStore.exception.CartException;


@Service
public class CartServiceImpl implements CartService
{
	@Autowired
	CartDao repo;
	
	@Autowired
	ProductsDao prepo;
	
	@Override
	public List<Cart> viewcartProducts() {
		
		return repo.findAll();
		
	}
	@Override
	public void addToCart(Cart cart) {
		
		repo.save(cart);
	}
	
	@Override
	public List<Cart> deleteFromCart(int id) {
	
		repo.deleteById(id);
		return repo.findAll();
		
	}
	@Override
	public int checkMinCost() {
		
	 return  repo.getCartSum();
	  
	}
	@Override
	public List<Products> viewProducts() {
		
		return prepo.findAll();
	}


}



