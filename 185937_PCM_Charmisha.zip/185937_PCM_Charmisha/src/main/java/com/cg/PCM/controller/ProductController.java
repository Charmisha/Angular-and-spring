package com.cg.PCM.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.PCM.bean.Product;
import com.cg.PCM.exception.ProductException;
import com.cg.PCM.service.IProductService;

@RestController
public class ProductController {
	
	@Autowired
	IProductService iPService;
	
	@RequestMapping(value="/createProduct", method=RequestMethod.POST)
	public List<Product> createProduct(@RequestBody Product product) throws ProductException{
		return iPService.createProduct(product);
	}
	
	@PutMapping("/updateProduct/{id}")
	public List <Product> updateProduct(@PathVariable int id, @RequestBody Product product) throws ProductException{
		return iPService.updateProduct(id, product);
	}
	
	@DeleteMapping("/deleteProduct/{id}")	
	public ResponseEntity<String> deleteProduct(@PathVariable int id) throws ProductException {
		iPService.deleteProduct(id);
	return new ResponseEntity<String> ("Product with id "+id+" deleted",HttpStatus.OK);
	}
	
	@RequestMapping("/products")
	public List <Product> viewProducts() throws ProductException
	{
		return iPService.viewProducts();
	}
	
	@RequestMapping("/product/{id}")
	public Product viewProductById(@PathVariable int id) throws ProductException{
	return iPService.findProductById(id);
}

}
