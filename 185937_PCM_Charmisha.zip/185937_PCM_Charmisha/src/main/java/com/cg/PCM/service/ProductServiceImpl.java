package com.cg.PCM.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;


import com.cg.PCM.bean.Product;
import com.cg.PCM.dao.IProductRepo;
import com.cg.PCM.exception.ProductException;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductRepo iPRepo;
	
	
	/*
	 * This method is used to create a new Product
	 */
	@Override
	public List<Product> createProduct(Product product) throws ProductException {
		
		try {
			iPRepo.save(product);
	        return iPRepo.findAll();
	        }catch(Exception e) {
	           throw new ProductException(e.getMessage());
	        }
	}
    
	/*
	 * This method is used to update a Product based on Id
	 */
	@Override
	public List<Product> updateProduct(int id, Product product) throws ProductException {
		
		try
		{
			Optional<Product> optional=iPRepo.findById(id);
			if(optional.isPresent())
			{
				Product p=optional.get();
				p.setName(product.getName());
				p.setModel(product.getModel());
				p.setPrice(product.getPrice());
				
				iPRepo.save(p);
				return viewProducts();
			}
			else
			{
				throw new ProductException("Product with Id"+id+" does not exist");	
			}
		}
			catch(Exception e) {
	            throw new ProductException(e.getMessage());
			
	}
	}

	/*
	 * This method is used to delete a Product based on Id
	 */
	@Override
	public void deleteProduct(int id) throws ProductException {
		
		try
		{
			iPRepo.deleteById(id);
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		
	}
     
	/*
	 * This method is used to show all the Products
	 */
	@Override
	public List<Product> viewProducts() throws ProductException {
	
		try
		{
			return iPRepo.findAll();
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
	}

	/*
	 * This method is used to find the Product based on Id
	 */
	@Override
	public Product findProductById(int id) throws ProductException {
		
		try
		{
			return iPRepo.findById(id).get();
		}
		catch (Exception ex)
		{
			throw new ProductException(ex.getMessage());
		}
	}

}
