package com.cg.PCM.service;

import java.util.List;

import com.cg.PCM.bean.Product;
import com.cg.PCM.exception.ProductException;


public interface IProductService {
	
	public List<Product> createProduct(Product product) throws ProductException;
	public List<Product> updateProduct(int id, Product product) throws ProductException;
	public void deleteProduct (int id) throws ProductException;
	public List<Product> viewProducts() throws ProductException;
	public Product findProductById(int id) throws ProductException;
}
