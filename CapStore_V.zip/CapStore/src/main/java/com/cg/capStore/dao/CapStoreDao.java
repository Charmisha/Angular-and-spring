package com.cg.capStore.dao;

import java.util.Date;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capStore.bean.CapStore;

public interface CapStoreDao extends JpaRepository<CapStore,String>{
	
	@Query("select revenue from CapStore where capDate=(select max(capDate) from CapStore)")
	double getCapStoreDetails();
	
	@Modifying
	@Query(value = "insert into CapStore (capDate,revenue) VALUES (:cDate,:amount)", nativeQuery = true)
	@Transactional
	void updateCapStoreRevenue(@Param("cDate") Date cDate,@Param("amount") Double amount);

}
