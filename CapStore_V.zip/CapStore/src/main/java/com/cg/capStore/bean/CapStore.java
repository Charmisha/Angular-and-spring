package com.cg.capStore.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CapStore {
	
	@Id
	private Date capDate;
	
	private double revenue;

	public Date getCapDate() {
		return capDate;
	}

	public void setCapDate(Date capDate) {
		this.capDate = capDate;
	}

	public double getRevenue() {
		return revenue;
	}

	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}
	
	
	

}
