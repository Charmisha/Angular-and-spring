package com.cg.capStore.service;

import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.capStore.bean.Cart;
import com.cg.capStore.bean.Products;
import com.cg.capStore.bean.User;
import com.cg.capStore.dao.CapStoreDao;
import com.cg.capStore.dao.CartDao;
import com.cg.capStore.dao.ProductsDao;
import com.cg.capStore.dao.UserDao;
import com.cg.capStore.exception.CartException;


@Service
public class CartServiceImpl implements CartService
{
	@Autowired
	CartDao repo;
	
	@Autowired
	ProductsDao prepo;
	
	@Autowired
	UserDao urepo;
	
	@Autowired
	CapStoreDao caprepo;
	
	@Override
	public List<Cart> viewcartProducts() {
		
		return repo.findAll();
		
	}
	@Override
	public void addToCart(Cart cart) {
		
		repo.save(cart);
	}
	
	@Override
	public List<Cart> deleteFromCart(int id) {
	
		repo.deleteById(id);
		return repo.findAll();
		
	}
	@Override
	public double checkCartTotal() {
		
	 return  repo.getCartSum();
	  
	}
	@Override
	public List<Products> viewProducts() {
		
		return prepo.findAll();
	}
	
	@Override
	public void placeOrder(User user) {
		
		Optional<User> u=urepo.findById(user.getAccountNo());
		
		if(u.isPresent())
		{
			User u1=u.get();
			if(u1.getPin().contentEquals(user.getPin()))
			{
				double cartValue=checkCartTotal();
				double accBal=u1.getAccountBalance();
				if(accBal>cartValue)
				{
					u1.setAccountBalance(accBal-cartValue);
					urepo.save(u1);
					updateRevenue(cartValue);
					
				}
			}
		}
	}
	@Override
	public void updateRevenue(double amount) {
		
		double currentRevenue=caprepo.getCapStoreDetails();
		double updatedRevenue=currentRevenue+amount;
		Date d=Calendar.getInstance().getTime();
		caprepo.updateCapStoreRevenue(d,updatedRevenue);
	}

}



