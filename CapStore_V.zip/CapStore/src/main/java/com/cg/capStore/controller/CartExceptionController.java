package com.cg.capStore.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class CartExceptionController
{
	public ResponseEntity<String> handleException(Exception ex)
	{
		return new ResponseEntity<String> ("Error: "+ex.getMessage(),HttpStatus.CONFLICT);
	}
}

