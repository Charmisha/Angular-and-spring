package com.cg.capStore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capStore.bean.User;


public interface UserDao extends JpaRepository<User,String>{

}
