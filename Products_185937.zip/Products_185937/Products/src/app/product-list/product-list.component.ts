import { Component, OnInit } from '@angular/core';
import {ProdutsService} from '../produts.service';
import {Product} from '../product';
import {HttpClient} from '@angular/common/http';
import {NgForm} from '@angular/forms';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  productsList=[];
  constructor(private pservice:ProdutsService) { 
    this.productsList=this.pservice.productList;
    console.log(this.productsList);
  }

  ngOnInit() {
    this.getProductsList();
  }
  getProductsList()
  {
    this.productsList=this.pservice.productList;
  }
  delete(id:string){
    this.pservice.deleteProduct(id);
    this.productsList= this.pservice.productList;
  }
}
