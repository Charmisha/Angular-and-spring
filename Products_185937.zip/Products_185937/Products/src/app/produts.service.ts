import { Injectable } from '@angular/core';
import { Product } from './product';
import { HttpClient,HttpClientModule} from '@angular/common/http';
import { StreamState } from 'http2';

@Injectable({
  providedIn: 'root'
})
export class ProdutsService {

  constructor(private httpClient: HttpClient) {

    this.getProductDetails().subscribe(data => this.productList = data);
    console.log(this.productList);
  }

  productList: Array<Product> = [];

  url: string = "/assets/db.json";


  getProductDetails(): any {
    //console.log(this.httpClient.get<Product>(this.url));
    return this.httpClient.get<Product>(this.url);
  }
  deleteProduct(id:string)
  {
    let i = 0;
    for (let product of this.productList) {
      if (product.id == id) {
        this.productList.splice(i, 1);
      }
      i++;
    }
  }
  products:Product[];
  searchProduct(data):Product[]
  { 
    this.products=[];
    for (let i of this.productList) {
      if(i.name === data.name || i.category===data.name)
       this.products.push(i);
    }
    console.log(this.products);
     return this.products;
  }
  

  
}

