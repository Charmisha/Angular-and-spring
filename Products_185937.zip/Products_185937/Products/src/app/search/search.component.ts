import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProdutsService } from '../produts.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  name:String[]=["Samsung","Redmi","Dell","Apple"];
  category:string[]=["mobile","laptop"];
  products:Array<Product>=[];
  constructor(private service:ProdutsService) { }

  ngOnInit() {
  }
  search(data)
  {
    console.log(data.name);
    this.products=this.service.searchProduct(data);
    console.log("hello"+this.products);
  }

}
