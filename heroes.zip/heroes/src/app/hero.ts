export class Hero
{
    id:number;
    name:String;
}