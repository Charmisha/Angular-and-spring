import {Hero} from  './hero';
export const HEROES:Hero[]=[
{id:1 ,name:'Superman'},
{id:2 ,name:'Spiderman'},
{id:3 ,name:'Hulk'},
{id:4,name:'Captain America'},
{id:5,name:'Thor'}
];